insert into reporte1(nombre_reporte1) 
select Nombre_empleado
from empleado
limit 5;

insert into reporte1(nombre_reporte1) 
select Nombre_cliente
from cliente
limit 5;

insert into reporte1(nombre_reporte1) 
select Nombre_proveedor
from proveedor
limit 5;






