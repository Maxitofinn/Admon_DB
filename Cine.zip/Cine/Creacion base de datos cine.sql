use cine;
Create table Cliente(
	id_cliente int auto_increment not null primary key,
    Nombre_cliente varchar(50)not null,
    Apellido_paterno_cliente varchar (30) not null,
    Apellido_materno_cliente varchar (30)not null,
    Sexo enum("Masculino","Femenino") not null,
    Edad int not null,
    Estado_residencia_cliente varchar(20),
    Municipio_cliente varchar(30)not null,
    Colonia_cliente varchar(30) not null,
    Calle_cliente varchar(30) not null,
    Numero_ext_cliente INT NOT NULL,
    Correo_cliente varchar(30) not null,
    Telefono varchar(15)
);
create table Sucursal(
	id_sucursal int auto_increment not null primary key,
    Nombre_sucursal varchar(30) not null,
    Estado_sucursal varchar(30) not null,
    Municipio_sucursal varchar(30) not null,
    Colonia_sucursal varchar(30) not null,
    Calle_sucursal varchar(30) not null,
    Numero_ext_sucursal varchar(30) not null
);
create table Empleado(
	id_empleado int auto_increment not null primary key,
    Nombre_empleado varchar(30) not null,
    Apellido_paterno_empleado varchar(30) not null,
    Apellido_materno_empleado varchar(30) not null,
    sexo_empleado enum("Masculino","Femenino") not null,
    edad_empleado int not null,
    Estado_residencia_empleado varchar(20),
    Municipio_empleado varchar(30)not null,
    Colonia_empleado varchar(30) not null,
    Calle_empleado varchar(30) not null,
    Numero_ext_empleado INT NOT NULL,
    Puesto_empleado varchar(30) not null,
    id_sucursal int,
	FOREIGN KEY (id_sucursal) REFERENCES Sucursal(id_sucursal)
);
create table Proveedor(
	id_proveedor int auto_increment not null primary key,
    Nombre_proveedor varchar(30) not null,
    Producto_suministrado varchar(30),
    id_sucursal int,
    foreign key(id_sucursal) references Sucursal(id_sucursal)
);

create table Pelicula(
	id_pelicula int auto_increment primary key not null,
    titulo_pelicula varchar(30) not null,
    genero_pelicula varchar(30) not null,
    duracion_pelicula int not null
	);
create table Funcion(
	id_funcion int auto_increment Primary key,
    id_pelicula int not null,
    id_sucursal int not null,
    horario_funcion DateTime not null,
    foreign key (id_pelicula) references Pelicula(id_pelicula),
    foreign key (id_sucursal) references Sucursal(id_sucursal)
);
create table Promocion(
	id_promocion int primary key auto_increment not null,
    descripcion_pelicula varchar(100),
    descuento Decimal(5,2)
);
Create table Venta (
	id_venta int auto_increment primary key not null,
    id_cliente int,
	id_empleado INT,
    id_promocion INT,
    id_funcion int,
    total_venta DECIMAL(8,2),
    fecha_venta DATE,
	foreign key (id_cliente) references Cliente(id_cliente),
    foreign key (id_empleado) references Empleado(id_empleado),
    foreign key (id_promocion) references Promocion(id_promocion),
    foreign key(id_funcion) references Funcion(id_funcion)
);

-- Registros para la tabla Cliente
INSERT INTO Cliente (Nombre_cliente, Apellido_paterno_cliente, Apellido_materno_cliente, Sexo, Edad, Estado_residencia_cliente, Municipio_cliente, Colonia_cliente, Calle_cliente, Numero_ext_cliente, Correo_cliente, Telefono) 
VALUES 
('Juan', 'Pérez', 'Gómez', 'Masculino', 28, 'CDMX', 'Cuauhtémoc', 'Roma Norte', 'Avenida Oaxaca', 123, 'juan.perez@mail.com', '555-1234'),
('María', 'López', 'Ramírez', 'Femenino', 34, 'CDMX', 'Benito Juárez', 'Del Valle', 'Calle de la Amistad', 234, 'maria.lopez@mail.com', '555-2345'),
('Carlos', 'Martínez', 'García', 'Masculino', 40, 'Jalisco', 'Guadalajara', 'Zapopan', 'Avenida Chapultepec', 345, 'carlos.martinez@mail.com', '333-3456'),
('Ana', 'Rodríguez', 'Sánchez', 'Femenino', 22, 'CDMX', 'Álvaro Obregón', 'Santa Fe', 'Calle de los Bosques', 456, 'ana.rodriguez@mail.com', '555-4567'),
('José', 'Hernández', 'Vázquez', 'Masculino', 55, 'Puebla', 'Puebla', 'Centro', 'Avenida Reforma', 567, 'jose.hernandez@mail.com', '222-5678'),
('Laura', 'González', 'Díaz', 'Femenino', 30, 'CDMX', 'Iztapalapa', 'Los Pinos', 'Calle 6', 678, 'laura.gonzalez@mail.com', '555-6789'),
('Miguel', 'Sánchez', 'López', 'Masculino', 27, 'Edomex', 'Toluca', 'Centro', 'Avenida Hidalgo', 789, 'miguel.sanchez@mail.com', '555-7890'),
('Patricia', 'Vega', 'Mendoza', 'Femenino', 44, 'Guerrero', 'Acapulco', 'Costera', 'Avenida Costera', 890, 'patricia.vega@mail.com', '777-8901'),
('Pedro', 'Jiménez', 'Figueroa', 'Masculino', 33, 'Morelos', 'Cuernavaca', 'Centro', 'Calle Guerrero', 123, 'pedro.jimenez@mail.com', '777-1234'),
('Elena', 'Torres', 'Jiménez', 'Femenino', 26, 'Hidalgo', 'Pachuca', 'Zona Centro', 'Avenida Las Torres', 234, 'elena.torres@mail.com', '555-2345');

-- Registros para la tabla Sucursal
INSERT INTO Sucursal (Nombre_sucursal, Estado_sucursal, Municipio_sucursal, Colonia_sucursal, Calle_sucursal, Numero_ext_sucursal) 
VALUES 
('Sucursal Roma', 'CDMX', 'Cuauhtémoc', 'Roma Norte', 'Avenida Oaxaca', '123'),
('Sucursal Polanco', 'CDMX', 'Miguel Hidalgo', 'Polanco', 'Avenida Presidente Masaryk', '456'),
('Sucursal Condesa', 'CDMX', 'Cuauhtémoc', 'Condesa', 'Avenida México', '789'),
('Sucursal Guadalajara', 'Jalisco', 'Guadalajara', 'Centro', 'Avenida Juárez', '101'),
('Sucursal Monterrey', 'Nuevo León', 'Monterrey', 'Centro', 'Avenida Constitución', '202'),
('Sucursal Puebla', 'Puebla', 'Puebla', 'Centro', 'Avenida Reforma', '303'),
('Sucursal Acapulco', 'Guerrero', 'Acapulco', 'Costera', 'Avenida Costera', '404'),
('Sucursal Toluca', 'Edomex', 'Toluca', 'Centro', 'Avenida Hidalgo', '505'),
('Sucursal Pachuca', 'Hidalgo', 'Pachuca', 'Zona Centro', 'Avenida Las Torres', '606'),
('Sucursal Cuernavaca', 'Morelos', 'Cuernavaca', 'Centro', 'Calle Guerrero', '707');

-- Registros para la tabla Empleado
INSERT INTO Empleado (Nombre_empleado, Apellido_paterno_empleado, Apellido_materno_empleado, sexo_empleado, edad_empleado, Estado_residencia_empleado, Municipio_empleado, Colonia_empleado, Calle_empleado, Numero_ext_empleado, Puesto_empleado, id_sucursal)
VALUES 
('Carlos', 'Vega', 'Ramírez', 'Masculino', 32, 'CDMX', 'Cuauhtémoc', 'Roma Norte', 'Avenida Oaxaca', 123, 'Gerente', 1),
('Patricia', 'López', 'Martínez', 'Femenino', 40, 'CDMX', 'Benito Juárez', 'Del Valle', 'Calle de la Amistad', 234, 'Supervisor', 2),
('Miguel', 'González', 'Díaz', 'Masculino', 28, 'Jalisco', 'Guadalajara', 'Zapopan', 'Avenida Chapultepec', 345, 'Cajero', 3),
('Ana', 'Rodríguez', 'Sánchez', 'Femenino', 25, 'CDMX', 'Álvaro Obregón', 'Santa Fe', 'Calle de los Bosques', 456, 'Vendedora', 4),
('José', 'Hernández', 'Vázquez', 'Masculino', 45, 'Puebla', 'Puebla', 'Centro', 'Avenida Reforma', 567, 'Gerente', 5),
('Laura', 'González', 'Mendoza', 'Femenino', 35, 'CDMX', 'Iztapalapa', 'Los Pinos', 'Calle 6', 678, 'Supervisor', 6),
('Pedro', 'Sánchez', 'López', 'Masculino', 50, 'Edomex', 'Toluca', 'Centro', 'Avenida Hidalgo', 789, 'Cajero', 7),
('Marta', 'Jiménez', 'Figueroa', 'Femenino', 31, 'Guerrero', 'Acapulco', 'Costera', 'Avenida Costera', 890, 'Vendedora', 8),
('Elena', 'Torres', 'Jiménez', 'Femenino', 29, 'Morelos', 'Cuernavaca', 'Centro', 'Calle Guerrero', 123, 'Gerente', 9),
('Antonio', 'Martínez', 'Gómez', 'Masculino', 38, 'Hidalgo', 'Pachuca', 'Zona Centro', 'Avenida Las Torres', 234, 'Supervisor', 10);

-- Registros para la tabla Proveedor
INSERT INTO Proveedor (Nombre_proveedor, Producto_suministrado, id_sucursal)
VALUES 
('Proveedor A', 'Papel', 1),
('Proveedor B', 'Proyector', 2),
('Proveedor C', 'Pantallas', 3),
('Proveedor D', 'Sillas', 4),
('Proveedor E', 'Sistema de sonido', 5),
('Proveedor F', 'Mobiliario', 6),
('Proveedor G', 'Cámaras', 7),
('Proveedor H', 'Películas', 8),
('Proveedor I', 'Cinescope', 9),
('Proveedor J', 'Luces', 10);

-- Registros para la tabla Pelicula
INSERT INTO Pelicula (titulo_pelicula, genero_pelicula, duracion_pelicula)
VALUES 
('Avengers', 'Acción', 150),
('Frozen', 'Animación', 120),
('Inception', 'Ciencia ficción', 148),
('Titanic', 'Romántica', 195),
('The Lion King', 'Animación', 88),
('Jurassic Park', 'Aventura', 127),
('Spider-Man', 'Acción', 120),
('Star Wars', 'Ciencia ficción', 121),
('The Godfather', 'Drama', 175),
('The Dark Knight', 'Acción', 152);

-- Registros para la tabla Funcion
INSERT INTO Funcion (id_pelicula, id_sucursal, horario_funcion)
VALUES 
(1, 1, '2025-05-06 18:00:00'),
(2, 2, '2025-05-06 19:00:00'),
(3, 3, '2025-05-07 20:00:00'),
(4, 4, '2025-05-07 21:00:00'),
(5, 5, '2025-05-08 18:30:00'),
(6, 6, '2025-05-08 19:30:00'),
(7, 7, '2025-05-09 20:00:00'),
(8, 8, '2025-05-09 21:00:00'),
(9, 9, '2025-05-10 18:00:00'),
(10, 10, '2025-05-10 19:00:00');

-- Registros para la tabla Promocion
INSERT INTO Promocion (descripcion_pelicula, descuento)
VALUES 
('Descuento en Avengers', 15.00),
('Descuento en Frozen', 10.00),
('Descuento en Inception', 20.00),
('Descuento en Titanic', 5.00),
('Descuento en The Lion King', 12.00),
('Descuento en Jurassic Park', 18.00),
('Descuento en Spider-Man', 25.00),
('Descuento en Star Wars', 10.00),
('Descuento en The Godfather', 30.00),
('Descuento en The Dark Knight', 15.00);

-- Registros para la tabla Venta
INSERT INTO Venta (id_cliente, id_empleado, id_promocion, total_venta, fecha_venta)
VALUES 
(1, 1, 1, 150.00, '2025-05-05'),
(2, 2, 2, 120.00, '2025-05-05'),
(3, 3, 3, 148.00, '2025-05-06'),
(4, 4, 4, 195.00, '2025-05-06'),
(5, 5, 5, 88.00, '2025-05-07'),
(6, 6, 6, 127.00, '2025-05-07'),
(7, 7, 7, 120.00, '2025-05-08'),
(8, 8, 8, 121.00, '2025-05-08'),
(9, 9, 9, 175.00, '2025-05-09'),
(10, 10, 10, 152.00, '2025-05-09');



