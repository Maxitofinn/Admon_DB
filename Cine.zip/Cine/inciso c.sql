CREATE VIEW Ultimos_3_Todos AS
SELECT * FROM (
    SELECT 'Cliente' AS Tabla, id_cliente AS ID, Nombre_cliente AS Nombre
    FROM Cliente
    ORDER BY id_cliente DESC
    LIMIT 3
) AS ultimos_clientes
UNION ALL
SELECT * FROM (
    SELECT 'Empleado' AS Tabla, id_empleado AS ID, Nombre_empleado AS Nombre
    FROM Empleado
    ORDER BY id_empleado DESC
    LIMIT 3
) AS ultimos_empleados
UNION ALL
SELECT * FROM (
    SELECT 'Proveedor' AS Tabla, id_proveedor AS ID, Nombre_proveedor AS Nombre
    FROM Proveedor
    ORDER BY id_proveedor DESC
    LIMIT 3
) AS ultimos_proveedores;

