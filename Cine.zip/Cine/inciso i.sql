create table Registro2 (
	id_registro2 int auto_increment primary key not null,
    nombre_registro2 varchar(30) not null,
    edad_registro2 int not null,
    sexo_registro2 enum("Masculino","Femenino"),
	Estado_registro2 varchar(20),
    Municipio_registro2 varchar(30)not null,
    Colonia_registro2 varchar(30) not null,
    Calle_registro2 varchar(30) not null,
    Numero_ext_registro2 INT NOT NULL
)