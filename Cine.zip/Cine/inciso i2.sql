create table Registro2_backup_copy like Registro2;

insert into registro2_backup_copy 
select * from registro2