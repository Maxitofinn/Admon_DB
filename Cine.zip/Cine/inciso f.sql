create table NuevoRegistro	( 
	id_NuevoRegistro int auto_increment not null primary key,
	Nombre_NuevoRegistro varchar(50)not null,
    Estado_NuevoRegistro varchar(20),
    Municipio_NuevoRegistro varchar(30)not null,
    Colonia_NuevoRegistro varchar(30) not null,
    Calle_NuevoRegistro varchar(30) not null,
    Numero_NuevoRegistro INT NOT NULL
)