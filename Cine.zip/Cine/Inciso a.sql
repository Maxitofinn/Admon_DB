-- Registros para la tabla Cliente (nombres americanos)
INSERT INTO Cliente (Nombre_cliente, Apellido_paterno_cliente, Apellido_materno_cliente, Sexo, Edad, Estado_residencia_cliente, Municipio_cliente, Colonia_cliente, Calle_cliente, Numero_ext_cliente, Correo_cliente, Telefono) 
VALUES 
('John', 'Smith', 'Johnson', 'Masculino', 29, 'California', 'Los Angeles', 'Hollywood', 'Sunset Boulevard', 101, 'john.smith@mail.com', '555-1001'),
('Emily', 'Davis', 'Miller', 'Femenino', 34, 'Texas', 'Houston', 'Downtown', 'Main Street', 202, 'emily.davis@mail.com', '555-1002'),
('Michael', 'Brown', 'Wilson', 'Masculino', 45, 'Florida', 'Miami', 'South Beach', 'Collins Avenue', 303, 'michael.brown@mail.com', '555-1003'),
('Jessica', 'Taylor', 'Moore', 'Femenino', 38, 'New York', 'New York', 'Manhattan', '5th Avenue', 404, 'jessica.taylor@mail.com', '555-1004'),
('David', 'Anderson', 'Thomas', 'Masculino', 50, 'Nevada', 'Las Vegas', 'The Strip', 'Sands Avenue', 505, 'david.anderson@mail.com', '555-1005'),
('Sarah', 'Jackson', 'White', 'Femenino', 31, 'Illinois', 'Chicago', 'Lincoln Park', 'North Avenue', 606, 'sarah.jackson@mail.com', '555-1006'),
('Daniel', 'Harris', 'Martin', 'Masculino', 28, 'Arizona', 'Phoenix', 'Tempe', 'University Drive', 707, 'daniel.harris@mail.com', '555-1007'),
('Olivia', 'Clark', 'Garcia', 'Femenino', 26, 'Colorado', 'Denver', 'Capitol Hill', 'Broadway Street', 808, 'olivia.clark@mail.com', '555-1008'),
('James', 'Lewis', 'Lee', 'Masculino', 41, 'Oregon', 'Portland', 'Pearl District', 'NW 23rd Avenue', 909, 'james.lewis@mail.com', '555-1009'),
('Ava', 'Walker', 'Allen', 'Femenino', 32, 'Ohio', 'Columbus', 'Short North', 'High Street', 1010, 'ava.walker@mail.com', '555-1010'),
('Ethan', 'Young', 'King', 'Masculino', 36, 'Georgia', 'Atlanta', 'Buckhead', 'Peachtree Road', 1111, 'ethan.young@mail.com', '555-1011'),
('Mia', 'Scott', 'Scott', 'Femenino', 29, 'North Carolina', 'Charlotte', 'Uptown', 'Tryon Street', 1212, 'mia.scott@mail.com', '555-1012'),
('Lucas', 'Adams', 'Baker', 'Masculino', 39, 'Utah', 'Salt Lake City', 'Downtown', 'State Street', 1313, 'lucas.adams@mail.com', '555-1013'),
('Charlotte', 'Gonzalez', 'Carter', 'Femenino', 30, 'Michigan', 'Detroit', 'Greektown', 'Monroe Street', 1414, 'charlotte.gonzalez@mail.com', '555-1014'),
('William', 'Mitchell', 'Perez', 'Masculino', 48, 'Washington', 'Seattle', 'Capitol Hill', 'E Pike Street', 1515, 'william.mitchell@mail.com', '555-1015');

-- Registros para la tabla Empleado (nombres americanos)
INSERT INTO Empleado (Nombre_empleado, Apellido_paterno_empleado, Apellido_materno_empleado, sexo_empleado, edad_empleado, Estado_residencia_empleado, Municipio_empleado, Colonia_empleado, Calle_empleado, Numero_ext_empleado, Puesto_empleado, id_sucursal)
VALUES 
('Benjamin', 'Roberts', 'Morris', 'Masculino', 33, 'California', 'Los Angeles', 'Santa Monica', 'Pico Boulevard', 201, 'Gerente', 1),
('Sophia', 'Nelson', 'Carter', 'Femenino', 38, 'Texas', 'Dallas', 'Oak Lawn', 'Maple Avenue', 202, 'Supervisor', 2),
('Joshua', 'Hernandez', 'Davis', 'Masculino', 29, 'New York', 'New York', 'Brooklyn', 'Flatbush Avenue', 203, 'Cajero', 3),
('Grace', 'Evans', 'Clark', 'Femenino', 27, 'Florida', 'Miami', 'Wynwood', 'NW 2nd Avenue', 204, 'Vendedora', 4),
('Noah', 'Wright', 'King', 'Masculino', 40, 'Illinois', 'Chicago', 'River North', 'Kinzie Street', 205, 'Gerente', 5),
('Isabella', 'Lopez', 'Martinez', 'Femenino', 34, 'Nevada', 'Las Vegas', 'Paradise', 'Tropicana Avenue', 206, 'Supervisor', 6),
('Alexander', 'Walker', 'Scott', 'Masculino', 42, 'Oregon', 'Portland', 'Sellwood', 'SE 13th Avenue', 207, 'Cajero', 7),
('Amelia', 'Parker', 'Robinson', 'Femenino', 28, 'Colorado', 'Denver', 'LoDo', 'Wazee Street', 208, 'Vendedora', 8),
('Mason', 'Torres', 'Evans', 'Masculino', 35, 'Georgia', 'Atlanta', 'Midtown', 'Peachtree Street', 209, 'Gerente', 9),
('Harper', 'Gonzalez', 'Perez', 'Femenino', 26, 'Ohio', 'Columbus', 'Brewery District', 'Front Street', 210, 'Supervisor', 10),
('Jackson', 'Miller', 'Davis', 'Masculino', 37, 'North Carolina', 'Charlotte', 'South End', 'South Boulevard', 211, 'Cajero', 1),
('Chloe', 'Young', 'Taylor', 'Femenino', 32, 'Utah', 'Salt Lake City', 'Sugarhouse', 'E 2100 S', 212, 'Vendedora', 2),
('Jack', 'Roberts', 'Johnson', 'Masculino', 50, 'Michigan', 'Detroit', 'Midtown', 'Cass Avenue', 213, 'Gerente', 3),
('Ella', 'Morris', 'Wilson', 'Femenino', 43, 'Washington', 'Seattle', 'Ballard', 'Market Street', 214, 'Supervisor', 4),
('Liam', 'Anderson', 'Taylor', 'Masculino', 39, 'Tennessee', 'Nashville', 'Music Row', 'Division Street', 215, 'Cajero', 5);

-- Registros para la tabla Proveedor (nombres americanos, sin repeticiones)
INSERT INTO Proveedor (Nombre_proveedor, Producto_suministrado, id_sucursal)
VALUES 
('Atlas Supply', 'Muebles', 1),
('BrightTech', 'Pantallas', 2),
('Cinema Gear', 'Proyectores', 3),
('SoundWave Inc', 'Sistemas de sonido', 4),
('Luxury Furniture', 'Mobiliario', 5),
('ScreenMaster', 'Pantallas', 6),
('OptiTech', 'Cámaras', 7),
('Echo Sound', 'Altavoces', 8),
('VisionPro', 'Luces', 9),
('Prime Cinema', 'Cámaras', 10),
('Silverlight Inc', 'Luces', 1),
('MaxVision', 'Proyectores', 2),
('Flexi Furniture', 'Muebles', 3),
('LuxeSystems', 'Sillas', 4),
('Startech', 'Tecnología audiovisual', 5);