insert into Registro2 (nombre_registro2,edad_registro2,sexo_registro2,Estado_registro2,Municipio_registro2,Colonia_registro2,Calle_registro2,Numero_ext_registro2)
select  Nombre_cliente,Edad,Sexo,Estado_residencia_cliente,Municipio_cliente,Colonia_cliente,Calle_cliente,Numero_ext_cliente
from cliente where Edad between 25 and 31
ORDER BY id_cliente DESC
    LIMIT 5;
    
insert into Registro2 (nombre_registro2,edad_registro2,sexo_registro2,Estado_registro2,Municipio_registro2,Colonia_registro2,Calle_registro2,Numero_ext_registro2)
select Nombre_empleado,edad_empleado,sexo_empleado,Estado_residencia_empleado,Municipio_empleado,Colonia_empleado,Calle_empleado,Numero_ext_empleado
from empleado where edad_empleado between 25 and 31
order by id_empleado desc
limit 5;
