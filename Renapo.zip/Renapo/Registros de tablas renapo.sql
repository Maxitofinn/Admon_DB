/*Se agregan los registros. 10 registros para cada tabla */

Insert into representante_de_familia (Nombre_representante, 
Apellido_Paterno_representante, Apellido_Materno_representante, 
Estado_civil_representante, Puesto_laboral_representante, Ingreso_mensual, Grado_academico) 
values("javier","Bautista","Jaso","Casado","Ingeniero en ciberseguridad",100000,"Licenciatura"),
	  ("Octavio","Maldonado","Villar","Casado","Ingeniero quimico",30000,"Licenciatura"),
      ("Oscar","Olmos","Quintero","Viudo","Ingeniero en informatica", 30000,"Licenciatura"),
	  ('Juan', 'Pérez', 'Sánchez', 'Soltero', 'Abogado', 25000, 'Licenciatura'),
	  ('Ana', 'Gómez', 'Martínez', 'Casado', 'Médico', 18000, 'Maestría'),
      ('Carlos', 'Díaz', 'López', 'Divorciado', 'Ingeniero', 30000, 'Doctorado'),
      ('Laura', 'Rodríguez', 'Hernández', 'Viudo', 'Profesor', 22000, 'Licenciatura'),
      ('Felipe', 'López', 'García', 'Casado', 'Contador', 25000, 'Maestría'),
      ('Marta', 'Fernández', 'Pérez', 'Soltero', 'Psicóloga', 19000, 'Licenciatura'),
      ('José', 'García', 'Ramírez', 'Viudo', 'Arquitecto', 24000, 'Doctorado');
      
	INSERT INTO vivienda (estado_vivienda, 
                      municipio_vivienda, 
                      colonia_vivienda, 
                      calle_vivienda, 
                      numero_exterior, 
                      numero_interior)
VALUES
    ('Puebla', 'Puebla', 'La Luz', '5 de Febrero', 101, 1),
    ('Veracruz', 'Veracruz', 'El Sol', 'Reforma', 202, 2),
    ('Jalisco', 'Guadalajara', 'Las Palmas', 'Juárez', 303, 3),
    ('Ciudad de México', 'CDMX', 'Centro', 'Constitución', 404, 4),
    ('Guerrero', 'Acapulco', 'La Estrella', 'Hidalgo', 505, 5),
    ('Oaxaca', 'Oaxaca', 'Bosques', 'Ávila Camacho', 606, 6),
    ('Querétaro', 'Querétaro', 'Jardines', 'Independencia', 707, 7),
    ('Sonora', 'Hermosillo', 'El Peñón', 'Morelos', 808, 8),
    ('Chiapas', 'Tuxtla', 'San Pedro', 'Benito Juárez', 909, 9),
    ('Michoacán', 'Morelia', 'La Montaña', 'Del Valle', 1001, 10);

INSERT INTO trabajador_social (RFC_trabajador_social, 
                               Nombre_trabajador_social, 
                               Apellido_Paterno_trabajador_social, 
                               Apellido_Materno_trabajador_social, 
                               Genero_trabajador_social)
VALUES
    ('JUAP123456HDFJRS00', 'Juan', 'Pérez', 'Sánchez', 'Hombre'),
    ('MARM987654MNBKLM01', 'María', 'González', 'Martínez', 'Mujer'),
    ('CARD456789LMSJPO02', 'Carlos', 'Díaz', 'López', 'Hombre'),
    ('LAUL234567TRZQXN03', 'Laura', 'Rodríguez', 'Hernández', 'Mujer'),
    ('FELF345678BRSAXO04', 'Felipe', 'López', 'García', 'Hombre'),
    ('MART234567BRVNGH05', 'Marta', 'Fernández', 'Pérez', 'Mujer'),
    ('JOSE987654LNPQSK06', 'José', 'García', 'Ramírez', 'Hombre'),
    ('ANAM123456JGHZMX07', 'Ana', 'Martínez', 'Díaz', 'Mujer'),
    ('RICR678901QWSZBN08', 'Ricardo', 'Sánchez', 'Gómez', 'Hombre'),
    ('SOFS234567NYVCWS09', 'Sofía', 'Ramírez', 'Rodríguez', 'Mujer');

INSERT INTO empleado_renapo (RFC_empleado, 
                             Nombre_empleado, 
                             Apellido_Paterno_empleado, 
                             Apellido_Materno_empleado, 
                             Genero_empleado, 
                             Puesto_empleado, 
                             Antiguedad_empleado)
VALUES
    ('JUAP123456HDFJRS00', 'Juan', 'Pérez', 'Sánchez', 'Hombre', 'Coordinador', 5),
    ('MARM987654MNBKLM01', 'María', 'González', 'Martínez', 'Mujer', 'Analista', 3),
    ('CARD456789LMSJPO02', 'Carlos', 'Díaz', 'López', 'Hombre', 'Supervisor', 10),
    ('LAUL234567TRZQXN03', 'Laura', 'Rodríguez', 'Hernández', 'Mujer', 'Director', 2),
    ('FELF345678BRSAXO04', 'Felipe', 'López', 'García', 'Hombre', 'Asistente', 8),
    ('MART234567BRVNGH05', 'Marta', 'Fernández', 'Pérez', 'Mujer', 'Jefe', 7),
    ('JOSE987654LNPQSK06', 'José', 'García', 'Ramírez', 'Hombre', 'Gerente', 1),
    ('ANAM123456JGHZMX07', 'Ana', 'Martínez', 'Díaz', 'Mujer', 'Ejecutivo', 4),
    ('RICR678901QWSZBN08', 'Ricardo', 'Sánchez', 'Gómez', 'Hombre', 'Auxiliar', 6),
    ('SOFS234567NYVCWS09', 'Sofía', 'Ramírez', 'Rodríguez', 'Mujer', 'Subdirector', 9);

INSERT INTO familia (Apellido_Paterno_familia, 
                     Apellido_Materno_familia, 
                     Empleado_familia, 
                     Representante_familia, 
                     Trabajador_social_familia, 
                     vivienda_familia)
VALUES
    ('Pérez', 'Sánchez', 1, 1, 1, 1),
    ('Gómez', 'Martínez', 2, 2, 2, 2),
    ('Díaz', 'López', 3, 3, 3, 3),
    ('Rodríguez', 'Hernández', 4, 4, 4, 4),
    ('López', 'García', 5, 5, 5, 5),
    ('Fernández', 'Pérez', 6, 6, 6, 6),
    ('García', 'Ramírez', 7, 7, 7, 7),
    ('Martínez', 'Díaz', 8, 8, 8, 8),
    ('Sánchez', 'Gómez', 9, 9, 9, 9),
    ('Ramírez', 'Rodríguez', 10, 10, 10, 10);


    