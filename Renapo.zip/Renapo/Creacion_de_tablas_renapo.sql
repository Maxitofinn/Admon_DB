use renapo;
Create table Familia(
	id_familia int not null auto_increment,
	Apellido_Paterno_familia varchar(30) not null,
	Apellido_Materno_familia varchar(30) not null,
	primary key(id_familia)
);
Create table Representante_de_familia(
	id_representante_de_familia int not null auto_increment,
    Nombre_representante varchar(30) not null,
    Apellido_Paterno_representante varchar(30) not null,
    Apellido_Materno_representante varchar(30) not null,
    Estado_civil_representante ENUM("Soltero","Casado","Divorciado","Viudo") not null,
    Puesto_laboral_representante varchar(30) not null,
    Ingreso_mensual int not null,
    Grado_academico varchar(30) not null,
    primary key(id_Representante_de_familia)
);
create table Empleado_renapo(
	numero_de_empleado int not null auto_increment,
    RFC_empleado varchar(20) not null,
    Nombre_empleado varchar(30) not null,
    Apellido_Paterno_empleado varchar(30) not null,
    Apellido_Materno_empleado varchar(30) not null,
    Genero_empleado ENUM("Hombre","Mujer") not null,
    Puesto_empleado varchar(30) not null,
    Antiguedad_empleado int not null,
    primary key(numero_de_empleado)
);
create table Trabajador_social(
	id_trabajador_social int not null auto_increment,
    RFC_trabajador_social varchar(20) not null,
    Nombre_trabajador_social varchar(30) not null,
    Apellido_Paterno_trabajador_social varchar(30) not null,
    Apellido_Materno_trabajador_social varchar(30) not null,
    Genero_trabajador_social ENUM("Hombre","Mujer") not null,
    primary key(id_trabajador_social)
    );
create table Vivienda(
	id_vivienda int not null auto_increment,
    estado_vivienda varchar(20) not null,
    municipio_vivienda varchar(30) not null,
    colonia_vivienda varchar(30) not null,
    calle_vivienda varchar(30) not null,
    numero_exterior int null,
    numero_interior int null,
    primary key(id_vivienda)
);
