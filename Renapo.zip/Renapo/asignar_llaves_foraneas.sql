alter table familia
add constraint fk_Representante_de_familia
foreign key (Representante_familia)
references Representante_de_familia(id_representante_de_familia);

alter table familia
add constraint fk_Empleado_renapo
foreign key(Empleado_familia)
references Empleado_renapo(numero_de_empleado);

alter table familia
add constraint fk_vivienda
foreign key(vivienda_familia)
references vivienda(id_vivienda);

alter table familia
add constraint fk_trabajador_social
foreign key(Trabajador_social_familia)
references Trabajador_social(id_trabajador_social);