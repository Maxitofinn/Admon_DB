use renapo;
alter table Familia
ADD column Empleado_familia int not null,
add column Representante_familia int not null,
add column Trabajador_social_familia int not null,
add column vivienda_familia int not null
;